# These Themes are meant only for BDv2, not BD nor BandagedBD. If you got either of those two go to [Themes](https://github.com/mwittrien/BetterDiscordAddons/tree/master/Themes/).[![Paypal][paypal-badge]][paypal-link] [![Patreon][patreon-badge]][patreon-link]

[paypal-badge]: https://img.shields.io/badge/Paypal-Donate!-%23003087.svg?logo=paypal&style=flat
[paypal-link]: https://paypal.me/MircoWittrien

[patreon-badge]: https://img.shields.io/badge/Patreon-Support!-%23F96854.svg?logo=patreon&style=flat
[patreon-link]: https://patreon.com/MircoWittrien

## Themes
 - There are no working Themes right now