# BetterDiscordAddons [![Paypal][paypal-badge]][paypal-link] [![Patreon][patreon-badge]][patreon-link]

[paypal-badge]: https://img.shields.io/badge/Paypal-Donate!-%23003087.svg?logo=paypal&style=flat
[paypal-link]: https://paypal.me/MircoWittrien

[patreon-badge]: https://img.shields.io/badge/Patreon-Support!-%23F96854.svg?logo=patreon&style=flat
[patreon-link]: https://patreon.com/MircoWittrien

A series of plugins and themes for BetterDiscord. If you got any question hit me up on Discord DevilBro#4401

## BDv1/BBD
### [Plugins](https://github.com/mwittrien/BetterDiscordAddons/tree/master/Plugins/)
### [Themes](https://github.com/mwittrien/BetterDiscordAddons/tree/master/Themes/)

## BDv2
### [Plugins](https://github.com/mwittrien/BetterDiscordAddons/tree/master/PluginsV2/)
### [Themes](https://github.com/mwittrien/BetterDiscordAddons/tree/master/ThemesV2/)
