## Themes [![Paypal][paypal-badge]][paypal-link] [![Patreon][patreon-badge]][patreon-link]

[paypal-badge]: https://img.shields.io/badge/Paypal-Donate!-%23003087.svg?logo=paypal&style=flat
[paypal-link]: https://paypal.me/MircoWittrien

[patreon-badge]: https://img.shields.io/badge/Patreon-Support!-%23F96854.svg?logo=patreon&style=flat
[patreon-link]: https://patreon.com/MircoWittrien

 - [Basic Background](https://github.com/mwittrien/BetterDiscordAddons/tree/master/Themes/BasicBackground) - Allows you to use a background image in Discord without greatly altering the basic look of Discord.
 - [BlurpleRecolor](https://github.com/mwittrien/BetterDiscordAddons/tree/master/Themes/BlurpleRecolor) - Replaces discords native blurple with your own color, change color in themefile
 - [Full Theme Dark](https://github.com/mwittrien/BetterDiscordAddons/tree/master/Themes/FullThemeDark) - Fixes all unthemed sections in the native dark theme of discord.
 - [Server Columns](https://github.com/mwittrien/BetterDiscordAddons/tree/master/Themes/ServerColumns) - Changes the Server List to a gridlike container to allow servers to be displayed in columns. Amount of columns can be set in the .theme.css file.
