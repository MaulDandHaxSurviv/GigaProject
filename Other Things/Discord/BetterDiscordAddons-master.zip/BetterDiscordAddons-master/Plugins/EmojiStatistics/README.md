# Emoji Statistics - [![Downlad][download-badge]][download-link] [![Paypal][paypal-badge]][paypal-link] [![Patreon][patreon-badge]][patreon-link] 

[download-badge]: https://img.shields.io/badge/Download-Plugin-brightgreen.svg?logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAQAAAAAYLlVAAAACXBIWXMAAA7EAAAOxAGVKw4bAAADGGlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjaY2BgnuDo4uTKJMDAUFBUUuQe5BgZERmlwH6egY2BmYGBgYGBITG5uMAxIMCHgYGBIS8/L5UBFTAyMHy7xsDIwMDAcFnX0cXJlYE0wJpcUFTCwMBwgIGBwSgltTiZgYHhCwMDQ3p5SUEJAwNjDAMDg0hSdkEJAwNjAQMDg0h2SJAzAwNjCwMDE09JakUJAwMDg3N+QWVRZnpGiYKhpaWlgmNKflKqQnBlcUlqbrGCZ15yflFBflFiSWoKAwMD1A4GBgYGXpf8EgX3xMw8BSMDVQYqg4jIKAUICxE+CDEESC4tKoMHJQODAIMCgwGDA0MAQyJDPcMChqMMbxjFGV0YSxlXMN5jEmMKYprAdIFZmDmSeSHzGxZLlg6WW6x6rK2s99gs2aaxfWMPZ9/NocTRxfGFM5HzApcj1xZuTe4FPFI8U3mFeCfxCfNN45fhXyygI7BD0FXwilCq0A/hXhEVkb2i4aJfxCaJG4lfkaiQlJM8JpUvLS19QqZMVl32llyfvIv8H4WtioVKekpvldeqFKiaqP5UO6jepRGqqaT5QeuA9iSdVF0rPUG9V/pHDBYY1hrFGNuayJsym740u2C+02KJ5QSrOutcmzjbQDtXe2sHY0cdJzVnJRcFV3k3BXdlD3VPXS8Tbxsfd99gvwT//ID6wIlBS4N3hVwMfRnOFCEXaRUVEV0RMzN2T9yDBLZE3aSw5IaUNak30zkyLDIzs+ZmX8xlz7PPryjYVPiuWLskq3RV2ZsK/cqSql01jLVedVPrHzbqNdU0n22VaytsP9op3VXUfbpXta+x/+5Em0mzJ/+dGj/t8AyNmf2zvs9JmHt6vvmCpYtEFrcu+bYsc/m9lSGrTq9xWbtvveWGbZtMNm/ZarJt+w6rnft3u+45uy9s/4ODOYd+Hmk/Jn58xUnrU+fOJJ/9dX7SRe1LR68kXv13fc5Nm1t379TfU75/4mHeY7En+59lvhB5efB1/lv5dxc+NH0y/fzq64Lv4T8Ffp360/rP8f9/AA0ADzT6lvFdAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAF1SURBVHja7JihTgNBEIb/K1WkBtEEAsESBKEvgEKRAhLHOxAMfQ9cHwEMBoFA1/ACBEGgzbkmUAwI+BENubTs9WZmLz1CZtZd9v7/u9vMZGdAGFabA05Hn3sWrYQwRB9rwafreikbQN5LiV6qhorDARzAARzAARzAARzAARzAARygGOAQ6a+GLr9jmlwpDuJbsxQrER+YYrXaI2D8EZyAEfangj2Fq0NrnBWry8YI5yb7rkRbBrDAK7X9NevlAYCL7Kns79iQKcunOU0+iO0fuSzV1QyUNjkU2b9wS66qm2nt8L3Q/oO7Gk3tWO2InzPtv3isU9RP9jqxmR8LMKsqdPVqFoC8qiDM/HiAcFUQZ34IYDr0VUGW+QEfK8BkVZBmfqkAWVWQZ37JAOA+n/nEtnh/wGd8JWP81Nt0P0r8Wu4ADvAHAOq2fsaP4N8BvFXi/ZoB3FYCcJMNKDbQw9Kc7YdoYfDzB+6xjUuM5mY+wsXYHvgeABIzsPkSOM/lAAAAAElFTkSuQmCC&style=flat
[download-link]: https://betterdiscord.net/ghdl?url=https://raw.githubusercontent.com/mwittrien/BetterDiscordAddons/master/Plugins/EmojiStatistics/EmojiStatistics.plugin.js

[paypal-badge]: https://img.shields.io/badge/Paypal-Donate!-%23003087.svg?logo=paypal&style=flat
[paypal-link]: https://paypal.me/MircoWittrien

[patreon-badge]: https://img.shields.io/badge/Patreon-Support!-%23F96854.svg?logo=patreon&style=flat
[patreon-link]: https://patreon.com/MircoWittrien

Adds several options to get more information about emojis and emojiservers.

- You can enable/disable the option to get the name and server of an emoji when you hover over it inside the emojipicker.
- You can enable/disable the option to add a button in the emojipicker to open an overview of your servers with some information.
